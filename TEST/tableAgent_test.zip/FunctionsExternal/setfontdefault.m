function setfontdefault(fontsize, fontname)
% setfont(fontsize, fontname)
fontdfault = 'Times New Roman';
% fontdfault = 'Cambria';
switch(nargin)
    
    case{1}
        fontname = fontdfault;
        set(0,'DefaultAxesFontName', fontdfault)
        set(0,'DefaultAxesFontSize', fontsize)
        
        % Change default text fonts.
        set(0,'DefaultTextFontname', fontdfault)
        set(0,'DefaultTextFontSize', fontsize)
        
        set(gca,'FontSize',fontsize,'Fontname', fontname)
        set(findall(gcf,'type','text'),'FontSize',fontsize,'Fontname', fontname)
     
    case{2}
        set(0,'DefaultAxesFontName', fontname)
        set(0,'DefaultAxesFontSize', fontsize)
        
        % Change default text fonts.
        set(0,'DefaultTextFontname', fontname)
        set(0,'DefaultTextFontSize', fontsize)
        
        set(gca,'FontSize',fontsize,'Fontname', fontname)
        set(findall(gcf,'type','text'),'FontSize',fontsize,'Fontname', fontname)
     
    otherwise
        fontname = fontdfault;
        fontsize = 8;
        set(0,'DefaultAxesFontName', fontname)
        set(0,'DefaultAxesFontSize', fontsize)
        
        % Change default text fonts.
        set(0,'DefaultTextFontname', fontname)
        set(0,'DefaultTextFontSize', fontsize)
        
        set(gca,'FontSize',fontsize,'Fontname', fontname)
        set(findall(gcf,'type','text'),'FontSize',fontsize,'Fontname', fontname)
  
end