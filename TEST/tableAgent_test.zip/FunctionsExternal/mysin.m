function y = mysin(x)
% for test of tableAgent
% TB = T.row().gen('Age=myxin(pi)',fnew,'fnew');
 y = sin(x);
end