function [obj]= head(obj,nrow)
narginchk(1,2);
if nargin == 1
    obj.table = obj.table(1:3,:);
elseif nargin == 2
    obj.table = obj.table(1:nrow,:);
else
    error('# of arg should be <=2')
end