function [obj]= tail(obj,nrow)
narginchk(1,2);
if nargin == 1
    obj.table = obj.table((end-3+1):end,:);
elseif nargin == 2
    obj.table = obj.table((end-nrow+1):end,:);
else
    error('# of arg should be <=2')
end