function [obj,Tmerge] = mergeWithLabel(obj,TB,key,varargin)
% [obj,Tmerge] = merge(obj,TB,key,varargin)

tA = obj.table;
if isa(TB,'tableAgent')
   tB = TB.table;
elseif istable(TB)
   tB = TB;
else
end

indKeyA = colstr2coldouble(obj,key);
indKeyB = colstr2coldouble(TB,key);
% deal with colnames
colNameLabelTA = obj.TcolLabel2colName;
colNameLabelTB = TB.TcolLabel2colName;
% makesure the colnames are unique
vA = string(colNameLabelTA.Name)+colNameLabelTA.Label;
vB = string(colNameLabelTB.Name)+colNameLabelTB.Label;
vAB = matlab.lang.makeValidName([vA;vB]);
vA2 = vAB(1:numel(vA));
vB2 = vAB((numel(vA)+1):end);
keyNewA = vA2(indKeyA);
keyNewB = vB2(indKeyB);
if ~all(strcmp(keyNewA,keyNewB))
   error('something is wrong, with keyA and keyB') 
end
tA.Properties.VariableNames = makeitcellstr(vA2);
tB.Properties.VariableNames = makeitcellstr(vB2);

[TM, Tmerge] = outerjoinSmartTables(tA,tB,makeitcellstr(keyNewA),varargin{:});
vTM = TM.Properties.VariableNames;

% rewrite Label
labelAB = string([colNameLabelTA.Label;colNameLabelTB.Label]);
nameAB = string([colNameLabelTA.Name;colNameLabelTB.Name]);
TmapAB = table(vAB,labelAB,nameAB);
[~,ia] = unique(TmapAB.vAB);
TmapABUnique = TmapAB(ia,:);
TmapABUnique.Row = makeitcellstr(TmapABUnique.vAB);
colnameM = cellstr(TmapABUnique{vTM,{'nameAB'}});
collabelM = cellstr(TmapABUnique{vTM,{'labelAB'}});
TM.Properties.VariableNames(vTM) = colnameM;

%% argout
obj.table = TM;
obj.TcolLabel2colName = table(colnameM,collabelM,'VariableNames',{'Name','Label'});
end