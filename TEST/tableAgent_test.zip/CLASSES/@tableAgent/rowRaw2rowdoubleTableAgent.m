function S = rowRaw2rowdoubleTableAgent(obj,S) % function defined this function
rowRaw = S(1).subs{1};
[rowselected]= rowRaw2rowDouble(obj.table,rowRaw);
S(1).subs{1} = rowselected;
end

