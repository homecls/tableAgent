function [T]= headwithLabel(obj,nrow)

narginchk(1,2);
if nargin == 1
    T = obj.table(1:3,:);
elseif nargin == 2
    T = obj.table(1:nrow,:);
else
    error('# of arg should be <=2')
    
end
CcolNameLabel = table2cell(obj.TcolLabel2colName)';
C = table2cell(T);
C = [CcolNameLabel; C];
T = cell2table(C);
% obj.table = T;
end